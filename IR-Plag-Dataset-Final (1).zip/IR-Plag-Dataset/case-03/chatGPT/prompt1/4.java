import java.util.Scanner;

public class BMICalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter weight in pounds
        System.out.print("Enter weight in pounds: ");
        double weight = scanner.nextDouble();

        // Prompt user to enter height in feet and inches
        System.out.print("Enter height in feet: ");
        double feet = scanner.nextDouble();
        System.out.print("Enter height in inches: ");
        double inches = scanner.nextDouble();

        // Calculate BMI and category
        double bmi = calculateBMI(weight, feet, inches);
        String category = getCategory(bmi);

        // Print BMI and category
        System.out.printf("BMI: %.2f%n", bmi);
        System.out.println("Category: " + category);

        scanner.close();
    }

    public static double calculateBMI(double weight, double feet, double inches) {
        // Calculate height in inches
        double height = feet * 12 + inches;

        // Calculate BMI
        return weight * 0.45359237 / ((height * 0.0254) * (height * 0.0254));
    }

    public static String getCategory(double bmi) {
        // Determine category based on BMI
        if (bmi < 18.5) {
            return "Underweight";
        } else if (bmi < 25) {
            return "Normal";
        } else if (bmi < 35) {
            return "Overweight";
        } else {
            return "Obese";
        }
    }
}
