import java.util.Scanner;

public class BMICalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double weight = 0.0;
        double feet = 0.0;
        double inches = 0.0;
        boolean isValidInput = false;

        do {
            try {
                // Prompt user to enter weight in pounds
                System.out.print("Enter weight in pounds: ");
                weight = scanner.nextDouble();

                // Prompt user to enter height in feet and inches
                System.out.print("Enter height in feet: ");
                feet = scanner.nextDouble();
                System.out.print("Enter height in inches: ");
                inches = scanner.nextDouble();

                // Calculate height in inches
                double height = feet * 12 + inches;

                // Calculate BMI
                double bmi = weight * 0.45359237 / ((height * 0.0254) * (height * 0.0254));

                // Print BMI and corresponding category
                System.out.printf("BMI: %.2f%n", bmi);
                if (bmi < 18.5) {
                    System.out.println("Underweight");
                } else if (bmi < 25) {
                    System.out.println("Normal");
                } else if (bmi < 35) {
                    System.out.println("Overweight");
                } else {
                    System.out.println("Obese");
                }

                isValidInput = true;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine();
            }
        } while (!isValidInput);

        scanner.close();
    }
}
