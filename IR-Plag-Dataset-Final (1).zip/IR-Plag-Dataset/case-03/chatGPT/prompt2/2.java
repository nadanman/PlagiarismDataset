import java.util.Scanner;

public class BMICalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter weight in pounds: ");
        double weight = sc.nextDouble();

        System.out.print("Enter height in feet and inches (e.g. 5.7): ");
        double feet = sc.nextDouble();
        double inches = sc.nextDouble();

        double bmi = calculateBMI(weight, feet, inches);

        System.out.printf("BMI: %.2f\n", bmi);
        if (bmi < 18.5) {
            System.out.println("BMI category: Underweight");
        } else if (bmi < 25) {
            System.out.println("BMI category: Normal");
        } else if (bmi < 35) {
            System.out.println("BMI category: Overweight");
        } else {
            System.out.println("BMI category: Obese");
        }

        sc.close();
    }

    public static double calculateBMI(double weight, double feet, double inches) {
        double heightInInches = feet * 12 + inches;
        return (weight * 703) / (heightInInches * heightInInches);
    }
}
