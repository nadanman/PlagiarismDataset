import java.util.Scanner;

public class BMICalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter weight in pounds
        System.out.print("Enter weight in pounds: ");
        double weight = scanner.nextDouble();

        // Prompt user to enter height in feet and inches
        System.out.print("Enter height in feet: ");
        double feet = scanner.nextDouble();
        System.out.print("Enter height in inches: ");
        double inches = scanner.nextDouble();

        // Calculate BMI and determine category
        double bmi = calculateBMI(weight, feet, inches);
        String category = determineCategory(bmi);

        // Print BMI and category
        System.out.println("BMI: " + bmi);
        System.out.println("Category: " + category);

        scanner.close();
    }

    public static double calculateBMI(double weight, double feet, double inches) {
        // Calculate height in inches
        double height = feet * 12 + inches;

        // Calculate BMI
        return weight * 703 / (height * height);
    }

    public static String determineCategory(double bmi) {
        // Determine category based on BMI
        String category;
        if (bmi < 18.5) {
            category = "Underweight";
        } else if (bmi < 25) {
            category = "Normal";
        } else if (bmi < 30) {
            category = "Overweight";
        } else {
            category = "Obese";
        }
        return category;
    }
}
