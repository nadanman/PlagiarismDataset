import java.util.Scanner;

public class BMICalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter weight in pounds
        System.out.print("Enter weight in pounds: ");
        double weight = scanner.nextDouble();

        // Prompt user to enter height in feet and inches
        System.out.print("Enter height in feet: ");
        double feet = scanner.nextDouble();
        System.out.print("Enter height in inches: ");
        double inches = scanner.nextDouble();

        // Calculate height in inches
        double height = feet * 12 + inches;

        // Calculate BMI
        double bmi = weight * 703 / (height * height);

        // Determine category based on BMI
        String category;
        if (bmi < 18.5) {
            category = "Underweight";
        } else if (bmi < 25) {
            category = "Normal";
        } else if (bmi < 30) {
            category = "Overweight";
        } else {
            category = "Obese";
        }

        // Print BMI and category
        System.out.printf("BMI: %.2f%n", bmi);
        System.out.println("Category: " + category);

        scanner.close();
    }
}
