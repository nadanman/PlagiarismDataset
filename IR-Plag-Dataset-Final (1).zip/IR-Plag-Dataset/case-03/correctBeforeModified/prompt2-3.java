import java.util.Scanner;

public class BMICalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter weight in pounds: ");
        double weight = sc.nextDouble();

        System.out.print("Enter height in feet and inches (e.g. 5 7): ");
        int feet = sc.nextInt();
        int inches = sc.nextInt();

        BMI bmi = new BMI(weight, feet, inches);

        System.out.printf("BMI: %.2f\n", bmi.getBMI());
        System.out.println("BMI category: " + bmi.getCategory());

        sc.close();
    }
}

class BMI {
    private double weight;
    private int feet;
    private int inches;
    private double bmi;

    public BMI(double weight, int feet, int inches) {
        this.weight = weight;
        this.feet = feet;
        this.inches = inches;
        calculateBMI();
    }

    private void calculateBMI() {
        int heightInInches = feet * 12 + inches;
        bmi = (weight * 703) / (heightInInches * heightInInches);
    }

    public double getBMI() {
        return bmi;
    }

    public String getCategory() {
        if (bmi < 18.5) {
            return "Underweight";
        } else if (bmi < 25) {
            return "Normal";
        } else if (bmi < 35) {
            return "Overweight";
        } else {
            return "Obese";
        }
    }
}
