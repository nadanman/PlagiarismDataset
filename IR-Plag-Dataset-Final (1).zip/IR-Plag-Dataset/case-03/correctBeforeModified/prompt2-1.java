public class BMICalculator {
    public static void main(String[] args) {
        if (args.length != 3) {
            System.out.println("Usage: java BMICalculator weight height_feet height_inches");
            System.exit(1);
        }

        double weight = Double.parseDouble(args[0]);
        int feet = Integer.parseInt(args[1]);
        int inches = Integer.parseInt(args[2]);

        int heightInInches = feet * 12 + inches;
        double bmi = (weight * 703) / (heightInInches * heightInInches);

        System.out.printf("BMI: %.2f\n", bmi);
        if (bmi < 18.5) {
            System.out.println("BMI category: Underweight");
        } else if (bmi < 25) {
            System.out.println("BMI category: Normal");
        } else if (bmi < 35) {
            System.out.println("BMI category: Overweight");
        } else {
            System.out.println("BMI category: Obese");
        }
    }
}
