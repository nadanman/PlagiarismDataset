import java.text.DecimalFormat;
import java.util.Scanner;

public class BMICalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter weight in pounds: ");
        double weight = sc.nextDouble();

        System.out.print("Enter height in feet and inches (e.g. 5 7): ");
        int feet = sc.nextInt();
        int inches = sc.nextInt();

        double heightInInches = feet * 12 + inches;
        double bmi = (weight * 703) / (heightInInches * heightInInches);

        DecimalFormat df = new DecimalFormat("0.00");

        System.out.println("BMI: " + df.format(bmi));

        if (bmi < 18.5) {
            System.out.println("BMI category: Underweight");
        } else if (bmi < 25) {
            System.out.println("BMI category: Normal");
        } else if (bmi < 35) {
            System.out.println("BMI category: Overweight");
        } else {
            System.out.println("BMI category: Obese");
        }

        sc.close();
    }
}
