import java.util.Scanner;

public class BMICalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter weight in pounds
        System.out.print("Enter weight in pounds: ");
        double weight = scanner.nextDouble();

        // Prompt user to enter height in feet and inches
        System.out.print("Enter height in feet: ");
        double feet = scanner.nextDouble();
        System.out.print("Enter height in inches: ");
        double inches = scanner.nextDouble();

        // Calculate height in inches
        double height = feet * 12 + inches;

        // Calculate BMI
        double bmi = weight * 703 / (height * height);

        // Determine category based on BMI
        String category;
        switch ((int) Math.floor(bmi / 5)) {
            case 0:
            case 1:
            case 2:
            case 3:
                category = "Underweight";
                break;
            case 4:
                category = "Normal";
                break;
            case 5:
                category = "Overweight";
                break;
            default:
                category = "Obese";
                break;
        }

        // Print BMI and category
        System.out.printf("BMI: %.2f%n", bmi);
        System.out.println("Category: " + category);

        scanner.close();
    }
}
