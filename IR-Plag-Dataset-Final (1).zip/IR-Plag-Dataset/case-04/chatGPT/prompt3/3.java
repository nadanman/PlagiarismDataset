public class MilesToKilometersTable {
    public static void main(String[] args) {
        String header = "╔══════╦═══════════════╗\n"
                      + "║ Miles║ Kilometers    ║\n"
                      + "╠══════╬═══════════════╣";
        String footer = "╚══════╩═══════════════╝";
        System.out.println(header);
        
        double miles, kilometers;
        for (int i = 1; i <= 10; i++) {
            miles = i;
            kilometers = miles * 1.609;
            System.out.printf("║ %4d ║ %10.3f    ║\n", i, kilometers);
        }
        
        System.out.println(footer);
    }
}
