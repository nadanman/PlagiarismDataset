public class MilesToKilometersTable {
    public static void main(String[] args) {
        System.out.println("+------+---------------+");
        System.out.println("| Miles| Kilometers    |");
        System.out.println("+------+---------------+");
        
        double miles, kilometers;
        for (int i = 1; i <= 10; i++) {
            miles = i;
            kilometers = miles * 1.609;
            System.out.format("| %4d | %10.3f    |\n", i, kilometers);
        }
        
        System.out.println("+------+---------------+");
    }
}
