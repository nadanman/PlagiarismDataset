public class MilesToKmTable4 {
    public static void main(String[] args) {
        double miles, kilometers;
        int[] milesArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        System.out.println("Miles\tKilometers");
        for (int milesValue : milesArray) {
            miles = milesValue;
            kilometers = miles * 1.609;
            System.out.printf("%d\t%.3f\n", milesValue, kilometers);
        }
    }
}
