public class MilesToKmTable8 {
    public static void main(String[] args) {
        double miles, kilometers;
        System.out.println("Miles\tKilometers");
        for (int i = 1; i <= 10; i++) {
            miles = i;
            switch (i) {
                case 1:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
                case 2:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
                case 3:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
                case 4:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
                case 5:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
                case 6:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
                case 7:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
                case 8:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
                case 9:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
                case 10:
                    kilometers = miles * 1.609;
                    System.out.printf("%d\t%.3f\n", i, kilometers);
                    break;
            }
        }
    }
}
