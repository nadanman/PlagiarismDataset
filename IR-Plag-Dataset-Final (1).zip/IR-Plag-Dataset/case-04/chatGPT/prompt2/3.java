public class MilesToKmTable7 {
    public static void main(String[] args) {
        double miles, kilometers;
        System.out.println("Miles\tKilometers");
        for (int i = 1; i <= 10; i++) {
            miles = i;
            for (int j = 0; j < 1; j++) {
                kilometers = miles * 1.609;
                System.out.printf("%d\t%.3f\n", i, kilometers);
            }
        }
    }
}
