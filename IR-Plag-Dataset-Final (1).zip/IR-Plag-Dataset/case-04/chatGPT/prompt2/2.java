public class MilesToKmTable5 {
    public static void main(String[] args) {
        double miles, kilometers;
        int[] milesArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int i = 0;
        System.out.println("Miles\tKilometers");
        while (i < milesArray.length) {
            miles = milesArray[i];
            kilometers = miles * 1.609;
            System.out.printf("%d\t%.3f\n", milesArray[i], kilometers);
            i++;
        }
    }
}
