public class MilesToKilometersTable {
    public static void main(String[] args) {
        final double KILOMETERS_PER_MILE = 1.609;
        
        System.out.println("Miles\tKilometers");
        int i = 1;
        do {
            double kilometers = i * KILOMETERS_PER_MILE;
            System.out.println(i + "\t" + String.format("%.3f", kilometers));
            i++;
        } while (i <= 10);
    }
}
