public class MilesToKilometersTable {
    public static void main(String[] args) {
        double miles = 1;
        
        System.out.println("Miles\tKilometers");
        while (miles <= 10) {
            double kilometers = miles * 1.609;
            System.out.printf("%.0f\t%.3f\n", miles, kilometers);
            miles++;
        }
    }
}
