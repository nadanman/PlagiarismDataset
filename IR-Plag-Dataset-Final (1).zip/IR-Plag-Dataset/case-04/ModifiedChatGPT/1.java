public class MilesToKilometers {
	public static void main(String[] args) {
		System.out.println("Miles\t\tKilometers");
		System.out.println("-------------------------------");

		// Use for loop
		for (int miles = 1; miles <= 10; miles++) {
			System.out.println(miles + "\t\t" + miles * 1.609);
		}
	}
}
