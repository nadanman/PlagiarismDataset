public class MilesToKilometers {
	public static void main(String[] args) {
		final int MAX_MILES = 10;
		
		System.out.println("Miles\t\tKilometers");
		System.out.println("-------------------------------");

		// Use while loop with a boolean condition
		int miles = 1;
		boolean continueLoop = true;
		while (continueLoop) {
			System.out.println(miles + "\t\t" + miles * 1.609);
			miles++;
			if (miles > MAX_MILES) {
				continueLoop = false;
			}
		}
	}
}
