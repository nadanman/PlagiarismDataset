public class MilesToKilometers {
	public static void main(String[] args) {
		System.out.println("Miles\t\tKilometers");
		System.out.println("-------------------------------");

		// Use enhanced for loop
		int[] milesArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		for (int miles : milesArray) {
			System.out.println(miles + "\t\t" + miles * 1.609);
		}
	}
}
