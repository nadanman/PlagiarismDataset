public class MilesToKilometers {
	private static final int MAX_MILES = 10;
	
	public static void main(String[] args) {
		System.out.println("Miles\t\tKilometers");
		System.out.println("-------------------------------");

		// Use while loop with a counter variable
		int miles = 1;
		int counter = 0;
		while (counter < MAX_MILES) {
			System.out.println(miles + "\t\t" + miles * 1.609);
			miles++;
			counter++;
		}
	}
}
