

/**
 *
 * @author CB6AB3315634A1E4D11B091BA48B60BA
 */
public class Nomor4_2451041557A22145B3701B0184109CAB013 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Miles \t Kilometers");
        for(int i = 1 ; i<=10;i++){
            System.out.println(i+" \t "+i*1.069);
        }
    }
    
}
