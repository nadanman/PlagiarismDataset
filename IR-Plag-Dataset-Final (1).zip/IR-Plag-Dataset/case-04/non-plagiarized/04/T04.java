/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 685903EF83F7A7C8A165F77EED160D9E
 */
public class T04 {
    public static void main(String[] args) {
        System.out.println("Miles           Kilometers");
        for (int i = 1; i < 10; i++) {
            System.out.println(i+"               "+i*1.609);
        }
        System.out.println(10+"              "+10*1.609);
    }
}
