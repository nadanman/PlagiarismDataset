public class MilesToKilometersTable {
    public static void main(String[] args) {
        final double KILOMETERS_PER_MILE = 1.609;
        
        System.out.println("Miles\tKilometers");
        int miles = 1;
        while (miles <= 10) {
            double kilometers = miles * KILOMETERS_PER_MILE;
            System.out.printf("%d\t%.3f\n", miles, kilometers);
            miles++;
        }
    }
}
