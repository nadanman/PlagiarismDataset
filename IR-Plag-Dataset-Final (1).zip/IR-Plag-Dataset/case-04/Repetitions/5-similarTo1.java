import java.text.DecimalFormat;

public class MilesToKilometersTable {
    public static void main(String[] args) {
        final double KILOMETERS_PER_MILE = 1.609;
        DecimalFormat decimalFormat = new DecimalFormat("#.###");
        
        System.out.println("Miles\tKilometers");
        for (int i = 1; i <= 10; i++) {
            double kilometers = i * KILOMETERS_PER_MILE;
            System.out.println(i + "\t" + decimalFormat.format(kilometers));
        }
    }
}
