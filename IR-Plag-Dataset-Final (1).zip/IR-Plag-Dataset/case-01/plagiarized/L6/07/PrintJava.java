/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author E3AFED0047B08059D0FADA10F400C1E5
 */
public class PrintJava {

    public static void main(String[] args) {
        printAll();
    }

    public static void printAll() {
        //mencetak welcome to java sebanyak 5 kali
        for (int i = 5; i > 0; i--) {
            System.out.print("Welcome to Java");
            System.out.println("");
        }
    }

}
