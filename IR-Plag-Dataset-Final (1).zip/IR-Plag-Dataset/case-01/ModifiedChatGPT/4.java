public class T1 {
	public static void main(String[] args) {
		String message = "Welcome to Java";
		System.out.println(message + "\n" + message + "\n" + message + "\n" + message + "\n" + message);
	}
}
