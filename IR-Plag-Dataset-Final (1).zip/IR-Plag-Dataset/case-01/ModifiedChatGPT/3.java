public class T1 {
	public static void main(String[] args) {
		int count = 5;
		do {
			System.out.println("Welcome to Java");
			count--;
		} while (count > 0);
	}
}
