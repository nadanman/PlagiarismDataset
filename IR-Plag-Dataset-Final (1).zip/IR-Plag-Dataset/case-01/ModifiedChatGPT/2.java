public class T1 {
	public static void main(String[] args) {
		int count = 0;
		while (count < 5) {
			System.out.println("Welcome to Java");
			count++;
		}
	}
}
