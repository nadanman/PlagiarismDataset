public class T1 {
	public static void main(String[] args) {
		String message = "Welcome to Java\n";
		StringBuilder sb = new StringBuilder(message);
		sb.append(message).append(message).append(message).append(message);
		System.out.println(sb.toString());
	}
}
