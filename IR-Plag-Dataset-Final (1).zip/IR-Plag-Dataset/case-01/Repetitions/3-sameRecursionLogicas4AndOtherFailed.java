public class WelcomeJava {
    public static void main(String[] args) {
        int count = 0;
        printWelcome(count);
    }

    public static void printWelcome(int count) {
        if (count < 5) {
            System.out.println("Welcome to Java");
            count++;
            printWelcome(count);
        }
    }
}
