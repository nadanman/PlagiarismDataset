public class WelcomeJava {
    public static void main(String[] args) {
        int count = 0;
        do {
            System.out.println("Welcome to Java");
            count++;
        } while (count < 5);
    }
}
