import java.util.stream.IntStream;

public class WelcomeJava {
    public static void main(String[] args) {
        IntStream.range(0, 5).forEach(i -> System.out.println("Welcome to Java"));
    }
}
