import java.util.Timer;
import java.util.TimerTask;

public class WelcomeJava {
    public static void main(String[] args) {
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            int count = 0;
            public void run() {
                if (count < 5) {
                    System.out.println("Welcome to Java");
                    count++;
                } else {
                    timer.cancel();
                }
            }
        };
        timer.schedule(task, 0, 1000);
    }
}
