public class WelcomeJava {
    public static void main(String[] args) {
        int i = 0;
        while (i < 5) {
            System.out.println("Welcome to Java");
            i++;
        }
    }
}
