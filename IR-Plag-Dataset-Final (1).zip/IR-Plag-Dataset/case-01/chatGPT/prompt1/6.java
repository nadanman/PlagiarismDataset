import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class WelcomeJava {
    public static void main(String[] args) {
        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
        Runnable task = () -> System.out.println("Welcome to Java");

        for (int i = 0; i < 5; i++) {
            executor.schedule(task, i + 1, TimeUnit.SECONDS);
        }

        executor.shutdown();
    }
}
