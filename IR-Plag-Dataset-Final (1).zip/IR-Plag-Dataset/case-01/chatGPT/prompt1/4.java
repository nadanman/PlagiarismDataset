public class WelcomeJava {
    public static void main(String[] args) {
        printWelcomeMessage(5);
    }

    public static void printWelcomeMessage(int n) {
        if (n > 0) {
            System.out.println("Welcome to Java");
            printWelcomeMessage(n-1);
        }
    }
}
