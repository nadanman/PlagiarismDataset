public class WelcomeJava {
    public static void main(String[] args) {
        StringBuilder message = new StringBuilder("Welcome to Java");
        for (int i = 0; i < 5; i++) {
            System.out.println(message);
        }
    }
}
