
/**
 *
 * @author 65FBEF05E01FAC390CB3FA073FB3E8CF (452BF208BF901322968557227B8F6EFE010)
 */
public class T01 {

    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            System.out.println("Welcome To Java");
        }
    }
}
