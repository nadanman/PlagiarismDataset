

/**
 *
 * @author 672CAF27F5363DC833BDA5099775E891
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String a = "Welcome To Java";
        for(int i=0;i<6;i++)
        {
            System.out.println(a);
        }
        
    }
    
}
