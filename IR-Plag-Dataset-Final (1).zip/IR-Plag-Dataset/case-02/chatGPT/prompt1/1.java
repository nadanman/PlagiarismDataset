import java.util.Scanner;

public class CylinderCalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the radius of the cylinder: ");
        double radius = input.nextDouble();
        
        System.out.print("Enter the length of the cylinder: ");
        double length = input.nextDouble();
        
        // Calculate the area and volume of the cylinder
        double area = radius * radius * 3.14159;
        double volume = area * length;
        
        // Display the results
        System.out.printf("The area of the cylinder is %.2f%n", area);
        System.out.printf("The volume of the cylinder is %.2f%n", volume);
        
        input.close();
    }
}
