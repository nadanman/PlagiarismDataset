import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CylinderCalculator {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        try {
            System.out.print("Enter the radius of the cylinder: ");
            double radius = Double.parseDouble(reader.readLine());
            
            System.out.print("Enter the length of the cylinder: ");
            double length = Double.parseDouble(reader.readLine());
            
            // Calculate the area and volume of the cylinder
            double area = radius * radius * Math.PI;
            double volume = area * length;
            
            // Display the results
            System.out.printf("The area of the cylinder is %.2f%n", area);
            System.out.printf("The volume of the cylinder is %.2f%n", volume);
        } catch (IOException e) {
            System.out.println("An error occurred while reading input.");
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.out.println("Invalid input format.");
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                System.out.println("An error occurred while closing the reader.");
                e.printStackTrace();
            }
        }
    }
}
