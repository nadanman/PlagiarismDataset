import javax.swing.JOptionPane;

public class CylinderCalculator {
    public static void main(String[] args) {
        String radiusStr = JOptionPane.showInputDialog("Enter the radius of the cylinder:");
        double radius = Double.parseDouble(radiusStr);
        
        String lengthStr = JOptionPane.showInputDialog("Enter the length of the cylinder:");
        double length = Double.parseDouble(lengthStr);
        
        // Calculate the area and volume of the cylinder
        double area = radius * radius * Math.PI;
        double volume = area * length;
        
        // Display the results
        String message = "The area of the cylinder is " + String.format("%.2f", area) + "\n"
                + "The volume of the cylinder is " + String.format("%.2f", volume);
        JOptionPane.showMessageDialog(null, message);
    }
}