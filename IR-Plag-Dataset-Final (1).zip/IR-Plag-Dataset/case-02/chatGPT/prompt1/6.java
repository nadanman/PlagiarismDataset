import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.IOException;

public class CylinderCalculator {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        OutputStreamWriter writer = new OutputStreamWriter(System.out);
        
        // Prompt the user to enter the radius and length of the cylinder
        writer.write("Enter the radius of the cylinder: ");
        writer.flush();
        double radius = Double.parseDouble(reader.readLine());
        
        writer.write("Enter the length of the cylinder: ");
        writer.flush();
        double length = Double.parseDouble(reader.readLine());
        
        // Calculate the area and volume of the cylinder
        double area = radius * radius * Math.PI;
        double volume = area * length;
        
        // Display the results
        writer.write(String.format("The area of the cylinder is %.2f%n", area));
        writer.write(String.format("The volume of the cylinder is %.2f%n", volume));
        writer.flush();
    }
}
