import java.util.Scanner;

public class CylinderAreaAndVolume {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt user for radius and length of the cylinder
        System.out.print("Enter the radius of the cylinder: ");
        double radius = input.nextDouble();

        System.out.print("Enter the length of the cylinder: ");
        double length = input.nextDouble();

        // Calculate the area and volume of the cylinder using the same formula
        double area = Math.PI * radius * radius;
        double volume = area * length;

        // Print the area and volume of the cylinder using a single printf statement
        System.out.printf("The area of the cylinder is: %.2f\nThe volume of the cylinder is: %.2f\n", area, volume);
    }
}
