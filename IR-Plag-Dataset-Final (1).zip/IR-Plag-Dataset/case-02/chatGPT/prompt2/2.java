import java.util.Scanner;

public class CylinderAreaAndVolume {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt user for radius and length of the cylinder
        System.out.print("Enter the radius of the cylinder: ");
        double radius = input.nextDouble();

        System.out.print("Enter the length of the cylinder: ");
        double length = input.nextDouble();

        // Calculate the area and volume of the cylinder using separate methods
        double area = calculateArea(radius);
        double volume = calculateVolume(radius, length);

        // Print the area and volume of the cylinder using separate methods
        printArea(area);
        printVolume(volume);
    }

    // Method to calculate the area of the cylinder base
    public static double calculateArea(double radius) {
        return Math.PI * radius * radius;
    }

    // Method to calculate the volume of the cylinder
    public static double calculateVolume(double radius, double length) {
        return calculateArea(radius) * length;
    }

    // Method to print the area of the cylinder
    public static void printArea(double area) {
        System.out.printf("The area of the cylinder is: %.2f\n", area);
    }

    // Method to print the volume of the cylinder
    public static void printVolume(double volume) {
        System.out.printf("The volume of the cylinder is: %.2f\n", volume);
    }
}
