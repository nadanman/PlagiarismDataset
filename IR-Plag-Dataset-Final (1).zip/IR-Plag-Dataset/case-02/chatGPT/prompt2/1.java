import java.util.Scanner;

public class CylinderAreaAndVolume {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt user for radius and length of the cylinder
        System.out.print("Enter the radius of the cylinder: ");
        double radius = input.nextDouble();

        System.out.print("Enter the length of the cylinder: ");
        double length = input.nextDouble();

        // Calculate the area and volume of the cylinder
        double area = calculateArea(radius);
        double volume = calculateVolume(radius, length);

        // Print the area and volume of the cylinder
        System.out.printf("The area of the cylinder is: %.2f\n", area);
        System.out.printf("The volume of the cylinder is: %.2f\n", volume);
    }

    // Method to calculate the area of the cylinder base
    public static double calculateArea(double radius) {
        double area = Math.PI * Math.pow(radius, 2);
        return area;
    }

    // Method to calculate the volume of the cylinder
    public static double calculateVolume(double radius, double length) {
        double volume = calculateArea(radius) * length;
        return volume;
    }
}
