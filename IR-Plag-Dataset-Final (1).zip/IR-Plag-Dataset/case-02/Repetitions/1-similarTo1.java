import java.util.Scanner;

public class CylinderCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Prompt the user to enter the radius and length of the cylinder
        System.out.print("Enter the radius of the cylinder: ");
        double radius = scanner.nextDouble();
        
        System.out.print("Enter the length of the cylinder: ");
        double length = scanner.nextDouble();
        
        // Calculate the area and volume of the cylinder
        double area = radius * radius * Math.PI;
        double volume = area * length;
        
        // Display the results
        System.out.printf("The area of the cylinder is %.2f%n", area);
        System.out.printf("The volume of the cylinder is %.2f%n", volume);
        
        scanner.close();
    }
}
