public class CylinderCalculator {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java CylinderCalculator <radius> <length>");
            return;
        }
        
        double radius = Double.parseDouble(args[0]);
        double length = Double.parseDouble(args[1]);
        
        // Calculate the area and volume of the cylinder
        double area = radius * radius * Math.PI;
        double volume = area * length;
        
        // Display the results
        System.out.printf("The area of the cylinder is %.2f%n", area);
        System.out.printf("The volume of the cylinder is %.2f%n", volume);
    }
}
