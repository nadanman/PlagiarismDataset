import javax.swing.JOptionPane;

public class CylinderCalculator {
    public static void main(String[] args) {
        String radiusInput = JOptionPane.showInputDialog("Enter the radius of the cylinder:");
        double radius = Double.parseDouble(radiusInput);
        
        String lengthInput = JOptionPane.showInputDialog("Enter the length of the cylinder:");
        double length = Double.parseDouble(lengthInput);
        
        // Calculate the area and volume of the cylinder
        double area = radius * radius * Math.PI;
        double volume = area * length;
        
        // Display the results
        JOptionPane.showMessageDialog(null, "The area of the cylinder is " + String.format("%.2f", area) + "\nThe volume of the cylinder is " + String.format("%.2f", volume));
    }
}
