import java.util.Scanner;

public class CylinderVolumeCalculator {
 public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	// Prompt the user to enter the radius and length of the cylinder
	System.out.print("Enter the radius and length of a cylinder, separated by a space: ");
	double radius = scanner.nextDouble();
	double length = scanner.nextDouble();

	double area = radius * radius * 3.14159;
	double volume = area * length;

	// Display the calculated area and volume of the cylinder
	System.out.println("The area of the cylinder is " + area + " square units.");
	System.out.println("The volume of the cylinder is " + volume + " cubic units.");
	}
}