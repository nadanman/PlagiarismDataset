import java.util.Scanner;

public class CylinderVolumeCalculator {
 public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	// Prompt the user to enter the dimensions of the cylinder
	System.out.print("Enter the dimensions of a cylinder (radius and length), separated by a space: ");
	double radius = scanner.nextDouble();
	double length = scanner.nextDouble();

	double area = Math.PI * Math.pow(radius, 2);
	double volume = area * length;

	// Display the calculated area and volume of the cylinder
	System.out.printf("The area of the cylinder is %.2f square units.%n", area);
	System.out.printf("The volume of the cylinder is %.2f cubic units.%n", volume);
 }
}
