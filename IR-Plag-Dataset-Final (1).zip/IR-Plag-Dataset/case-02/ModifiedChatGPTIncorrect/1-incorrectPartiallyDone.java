public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);

	// Prompt the user to enter the dimensions of the cylinder
	System.out.print("Enter the dimensions of a cylinder (radius and length), separated by a space: ");
	double radius = scanner.nextDouble();
	double length = scanner.nextDouble();

	double area = PI * Math.pow(radius, 2);
	double volume = area * length;

	// Display the calculated area and volume of the cylinder
