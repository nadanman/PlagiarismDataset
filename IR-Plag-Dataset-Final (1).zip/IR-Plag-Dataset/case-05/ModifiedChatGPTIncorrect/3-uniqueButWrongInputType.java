public class ReverseSentence {
    public static void main(String[] args) {
        System.out.print("Enter a sentence: ");
        java.util.Scanner input = new java.util.Scanner(System.in);
        String sentence = input.nextLine();
        String reversed = reverse(sentence);
        System.out.println("Reversed sentence: " + reversed);
    }

    public static String reverse(String sentence) {
        String[] words = sentence.split("\\s+");
        String reversed = "";
        for (int i = words.length - 1; i >= 0; i--) {
            reversed += words[i] + " ";
        }
        return reversed.trim();
    }
}
