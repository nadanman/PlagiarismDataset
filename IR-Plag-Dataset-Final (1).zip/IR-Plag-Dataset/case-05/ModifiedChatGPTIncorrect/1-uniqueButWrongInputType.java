public class ReverseString {
    public static void main(String[] args) {
        System.out.print("Enter a string: ");
        java.util.Scanner input = new java.util.Scanner(System.in);
        String str = input.nextLine();
        String reversed = reverse(str);
        System.out.println("Reversed string: " + reversed);
    }

    public static String reverse(String str) {
        String reversed = "";
        for (int i = str.length() - 1; i >= 0; i--) {
            reversed += str.charAt(i);
        }
        return reversed;
    }
}
