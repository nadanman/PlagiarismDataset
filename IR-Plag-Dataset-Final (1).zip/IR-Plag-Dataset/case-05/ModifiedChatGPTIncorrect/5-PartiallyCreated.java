public class ReverseLinkedList {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    static Node head;

    public static void main(String[] args) {
        System.out.print("Enter linked list size: ");
        java.util.Scanner input = new java.util.Scanner(System.in);
        int size = input.nextInt();
        System.out.print("Enter linked list elements: ");
        for (int i = 0; i < size; i++) {
            int data = input.nextInt();
           
