public class ReverseArray {
    public static void main(String[] args) {
        System.out.print("Enter array size: ");
        java.util.Scanner input = new java.util.Scanner(System.in);
        int size = input.nextInt();
        int[] array = new int[size];
        System.out.print("Enter array elements: ");
        for (int i = 0; i < size; i++) {
            array[i] = input.nextInt();
        }
        reverse(array);
        System.out.print("Reversed array: ");
        for (int i = 0; i < size; i++) {
            System.out.print(array[i] + " ");
        }
    }

    public static void reverse(int[] array) {
        int left = 0;
        int right = array.length - 1;
        while (left < right) {
            int temp = array[left];
            array[left] = array[right];
            array[right] = temp;
            left++;
            right--;
        }
    }
}
