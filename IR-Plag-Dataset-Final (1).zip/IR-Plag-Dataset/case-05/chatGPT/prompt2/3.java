import java.util.Scanner;

public class ReverseInteger {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();
        reverse(number);
    }
    
    public static void reverse(int number) {
        String numberStr = String.valueOf(number);
        StringBuilder reverseNumber = new StringBuilder(numberStr).reverse();
        System.out.println("Reverse of the number: " + reverseNumber);
    }
}
