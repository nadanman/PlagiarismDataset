import java.util.Scanner;

public class ReverseInteger {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();
        System.out.print("Reverse of the number: ");
        reverse(number);
    }

    public static void reverse(int number) {
        int originalNumber = number;
        int reverseNumber = 0;
        while (number > 0) {
            reverseNumber = reverseNumber * 10 + (number % 10);
            number = number / 10;
        }
        System.out.println("The reverse of " + originalNumber + " is " + reverseNumber);
    }
}
