import java.util.Scanner;

public class ReverseInteger {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();
        reverse(number);
    }
    
    public static void reverse(int number) {
        int reversedNumber = 0;
        while (number != 0) {
            reversedNumber = reversedNumber * 10 + (number % 10);
            number /= 10;
        }
        System.out.print("Reverse of the number: ");
        while (reversedNumber != 0) {
            System.out.print(reversedNumber % 10);
            reversedNumber /= 10;
        }
        System.out.println();
    }
}
