import java.util.Scanner;

public class ReverseInteger {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();
        reverse(number);
    }
    
    public static void reverse(int number) {
        StringBuilder sb = new StringBuilder();
        while (number != 0) {
            sb.append(number % 10);
            number /= 10;
        }
        System.out.println("Reverse of the number: " + sb.reverse().toString());
    }
}
