public class T6 {
    public static void main(String[] args) {
        int[] num = new int[10];
        
        try (java.util.Scanner input = new java.util.Scanner(System.in)) {
            for (int i = 0; i < 10; i++) {
                System.out.print("Read a number: ");
                num[i] = input.nextInt();
            }
        }

        for (int n : num) {
            System.out.println(n);
        }
    }
}
