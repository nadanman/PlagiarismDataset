import java.util.LinkedList;
import java.util.Scanner;

public class ReverseIntegers {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        LinkedList<Integer> integers = new LinkedList<Integer>();

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            integers.add(input.nextInt());
        }

        System.out.println("The integers in reversed order are:");
        while (!integers.isEmpty()) {
            System.out.println(integers.removeLast());
        }
    }
}
