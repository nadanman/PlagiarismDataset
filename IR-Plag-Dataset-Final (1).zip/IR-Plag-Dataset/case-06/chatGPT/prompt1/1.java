import java.util.Scanner;

public class ReverseIntegers {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[] integers = new int[10];

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            integers[i] = input.nextInt();
        }

        System.out.println("The integers in reversed order are:");
        for (int i = 9; i >= 0; i--) {
            System.out.println(integers[i]);
        }
    }
}
