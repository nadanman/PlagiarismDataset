import java.util.Scanner;

public class ReverseIntegers {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[] integers = new int[10];

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            integers[i] = input.nextInt();
        }

        int temp;
        for (int i = 0; i < 5; i++) {
            temp = integers[i];
            integers[i] = integers[9 - i];
            integers[9 - i] = temp;
        }

        System.out.println("The integers in reversed order are:");
        for (int i = 0; i < 10; i++) {
            System.out.println(integers[i]);
        }
    }
}
