import java.util.Scanner;

public class ReverseIntegers {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[] integers = new int[10];

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            integers[i] = input.nextInt();
        }

        System.out.println("The integers in reversed order are:");
        reverseIntegers(integers, 0);
    }

    public static void reverseIntegers(int[] integers, int index) {
        if (index == integers.length) {
            return;
        }
        reverseIntegers(integers, index + 1);
        System.out.println(integers[index]);
    }
}
