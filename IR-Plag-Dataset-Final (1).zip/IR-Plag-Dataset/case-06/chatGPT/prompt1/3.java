import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ReverseIntegers {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        List<Integer> integers = new ArrayList<Integer>();

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            integers.add(input.nextInt());
        }

        Collections.reverse(integers);

        System.out.println("The integers in reversed order are:");
        for (int i = 0; i < 10; i++) {
            System.out.println(integers.get(i));
        }
    }
}
