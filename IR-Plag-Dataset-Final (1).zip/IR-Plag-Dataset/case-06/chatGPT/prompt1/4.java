import java.util.Scanner;
import java.util.Stack;

public class ReverseIntegers {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Stack<Integer> integers = new Stack<Integer>();

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            integers.push(input.nextInt());
        }

        System.out.println("The integers in reversed order are:");
        while (!integers.isEmpty()) {
            System.out.println(integers.pop());
        }
    }
}
