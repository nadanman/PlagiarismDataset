import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ReverseOrderUsingArrayList {
    public static void main(String[] args) {
        ArrayList<Integer> nums = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter 10 integers: ");
        for (int i = 0; i < 10; i++) {
            nums.add(scanner.nextInt());
        }
        System.out.println("Numbers in reverse order:");
        Collections.reverse(nums);
        for (int num : nums) {
            System.out.print(num + " ");
        }
    }
}
