import java.util.LinkedList;
import java.util.Scanner;

public class ReverseOrderUsingLinkedList {
    public static void main(String[] args) {
        LinkedList<Integer> nums = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter 10 integers: ");
        for (int i = 0; i < 10; i++) {
            nums.add(scanner.nextInt());
        }
        System.out.println("Numbers in reverse order:");
        for (int i = nums.size() - 1; i >= 0; i--) {
            System.out.print(nums.get(i) + " ");
        }
    }
}
