import java.util.HashSet;
import java.util.Scanner;

public class ReverseOrderUsingHashSet {
    public static void main(String[] args) {
        HashSet<Integer> nums = new HashSet<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter 10 integers: ");
        for (int i = 0; i < 10; i++) {
            nums.add(scanner.nextInt());
        }
        System.out.println("Numbers in reverse order:");
        for (int i = 10; i >= 0; i--) {
            if (nums.contains(i)) {
                System.out.print(i + " ");
            }
        }
    }
}
