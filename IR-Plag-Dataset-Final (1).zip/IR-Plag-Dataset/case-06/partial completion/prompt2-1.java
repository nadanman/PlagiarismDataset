import java.util.PriorityQueue;
import java.util.Scanner;

public class ReverseOrderUsingPriorityQueue {
    public static void main(String[] args) {
        PriorityQueue<Integer> nums = new PriorityQueue<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter 10 integers: ");
        for (int i = 0; i < 10; i++) {
            nums.offer(scanner.nextInt());
        }
        System.out.println("Numbers in reverse order:");
        while (!nums.isEmpty()) {
            System.out.print(nums.poll() + " ");
        }
    }
}
