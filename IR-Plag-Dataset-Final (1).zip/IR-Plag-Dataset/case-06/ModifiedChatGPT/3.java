public class T6 {
    public static void main(String[] args) {
        int[] num = new int[10];

        java.util.Scanner input = new java.util.Scanner(System.in);

        int i = 0;
        do {
            System.out.print("Read a number: ");
            if (input.hasNextInt()) {
                num[i] = input.nextInt();
                i++;
            } else {
                String invalidInput = input.next();
                switch (invalidInput) {
                    case "quit":
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid input!");
                        break;
                }
            }
        } while (i < 10);

        input.close();

        for (int j = 9; j >= 0; j--) {
            System.out.println(num[j]);
        }
    }
}
