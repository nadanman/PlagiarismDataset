public class T6 {
    public static void main(String[] args) {
        int[] num = readNumbers(10);

        for (int i = 9; i >= 0; i--) {
            System.out.println(num[i]);
        }
    }

    private static int[] readNumbers(int count) {
        int[] num = new int[count];

        java.util.Scanner input = new java.util.Scanner(System.in);

        for (int i = 0; i < count; i++) {
            System.out.print("Read a number: ");
            num[i] = input.nextInt();
        }

        input.close();
        return num;
    }
}
