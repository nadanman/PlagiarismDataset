import java.util.Arrays;
import java.util.Scanner;

public class T6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[] num = Arrays.stream(new int[10])
                .map(i -> {
                    System.out.print("Read a number: ");
                    return input.nextInt();
                })
                .toArray();

        input.close();

        Arrays.stream(num)
                .boxed()
                .sorted((a, b) -> b.compareTo(a))
                .forEach(System.out::println);
    }
}
